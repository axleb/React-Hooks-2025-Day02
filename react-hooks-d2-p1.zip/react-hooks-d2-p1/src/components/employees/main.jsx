import { useState, useEffect } from "react";
//
function Main() {
  const [allEmployees, setAllEmployees] = useState([]);

    useEffect(()=>{
      fetch("http://localhost:3030/employees")
      .then(data => data.json())
      .then(resolvedData => setAllEmployees(resolvedData))
      .catch((error)=>{
        console.error("Error fetching employees! + " + error.message); 
      });
    },[]);

    return (
      <main>
        <h2>Employee List</h2>
        {
          allEmployees.map((customer, i) =>
            (<div key={i}>
              {customer.username}&nbsp;
              {customer.password}
            </div>)
          )
        }
      </main>
    )
  };
//
export default Main;
