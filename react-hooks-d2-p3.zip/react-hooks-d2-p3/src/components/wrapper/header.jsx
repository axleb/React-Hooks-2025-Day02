import logo from "./../../assets/chart.gif";
import { NavLink } from "react-router-dom";
import {useContext, useState} from "react";
import {AuthContext} from "./../AuthContext";
import Popup from "./popup";
//
function Header(){
  const {user, logout} = useContext(AuthContext);
  const [showPopup, setShowPopup] = useState(false);
  const handleLogoutClick = () => setShowPopup(true);
  const handleConfirmLogout = () => {
    logout();
    setShowPopup(false);
  };
  const handleCancelLogout = () => setShowPopup(false);
//
  return (
    <header>
      <img src={logo} id="logo" />
			<h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
      <nav>

        <ul>
          <li><NavLink to="/">home</NavLink></li>
          <li><NavLink to="/register">register</NavLink></li>
          <li><NavLink to="/employees">employees</NavLink></li>

          { !user? (
            <li><NavLink to="/login">login</NavLink></li>
            ):(
            <li onClick={handleLogoutClick}> {user.username} </li>
          )}

        </ul>
      </nav>
      {showPopup && (
        <Popup
          message="Are you sure you want to logout?"
          onConfirm={handleConfirmLogout}
          onCancel={handleCancelLogout}
        />
      )}
    </header>
  )
};
//
export default Header;
//


