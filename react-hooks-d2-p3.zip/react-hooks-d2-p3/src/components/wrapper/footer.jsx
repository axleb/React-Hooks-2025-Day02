//
function Footer(){
  return (
    <footer>
      <hr />
      Copyright &copy; 2025. All rights reserved
    </footer>
  )
};
//
export default Footer;
