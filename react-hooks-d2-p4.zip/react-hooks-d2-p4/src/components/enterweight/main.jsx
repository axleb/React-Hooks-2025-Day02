import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../AuthContext";
//
function Main() {
//
  const [userweight, setUserWeight] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);

//
  const handleFieldChange = (event) => {
    const { name, value } = event.target;
    if (name === "userweight") setUserWeight(value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    fetch('http://localhost:3030/employees', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        userweight: userweight,
      })
    })
    .then(response => response.text())
    .then(() => {
      setIsSubmitting(true);
      navigate("/");
    })
    .catch(err => {
      console.log("An error occured! " + err.message);
    });
  };
//
  return (
    <main>
      <h2>Enter weight for today</h2>
      {user ? (
        <form onSubmit={handleSubmit}>
          <div>
            <label>
              Today's Weight:
                <input 
                type="text" 
                name="userweight" 
                onChange={handleFieldChange} />
            </label>
          </div>
          <div>
            <input type="submit" value="Submit" disabled={isSubmitting} />
          </div>
        </form>
      ) : (
        <h4>You must be logged in to post a weight</h4>
      ) }
      
    </main>
  );
};
//
export default Main;
