import "./styles.css";
import { AuthProvider } from "./components/authcontext";
import Home from "./components/home/home";
import Employees from "./components/employees/employees";
import Register from "./components/register/register";
import Login from "./components/login/login";
import EnterWeight from "./components/enterweight/enterweight";
//
import { BrowserRouter, Route, Routes } from "react-router-dom";
//
function App() {
  return (
    <>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/employees' element={<Employees />} />
            <Route path='/register' element={<Register />} />
            <Route path='/login' element={<Login />} />
            <Route path='/enterweight' element={<EnterWeight />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </>
  )
};
//
export default App;
