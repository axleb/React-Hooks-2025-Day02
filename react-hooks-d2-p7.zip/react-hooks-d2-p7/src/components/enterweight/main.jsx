import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../authcontext";
//
function Main (props) {
//
  const [userweight, setUserWeight] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const {user} = useContext(AuthContext);
  const [error, setError] = useState("");
  const navigate = useNavigate();
//
  const handleFieldChange = (event) => { 
    const { name, value } = event.target;
    if (name === "userweight") setUserWeight(value);
  };
  const handleSubmit = (event) => { 
    event.preventDefault();
    setError("");
    if (userweight === "") {
      setError("Weight is required.");
      return;
    }
    const numWeight = Number(userweight);
    if (isNaN(numWeight)) {
      setError("Weight must be a number.");
      return;
    }
    if (numWeight < 20 || numWeight > 250) {
      setError("Weight must be between 20 and 250.");
      return;
    }

    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    const formattedDate = `${day}/${month}/${year}`;

    const payload = {
      id: user.id,
      weight: String(userweight),
      date: formattedDate
    };

    fetch('http://localhost:3030/weights',
      {
        method: 'POST',
        headers: { 
          'Accept': 'application/json',
          'Content-Type': 'application/json'  
        },
        body: JSON.stringify(payload)
      }
    )
    .then(response => {
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("Resource not found. The server endpoint may be incorrect.");
        };
        throw new Error(`Server error: ${response.status}`);
      };
      return response.text()
    })
    .then(text => {
      if (text) {
        try {
          JSON.parse(text);
        } catch (e) {
          throw new Error('Invalid JSON response: ' + text);
        };
      };
    })
    .then(emp => {
      //setUserWeight("");
      setIsSubmitting(true);
      navigate("/");
    })
    .catch(err => {
      console.log("An error occured! " + err.message);
    });
  };
  //
  return (
    <main>
      {user ? (
      <>
        <h2>Enter your weight for today</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label>
              Today's weight:
                <input 
                  type="text" 
                  name="userweight" 
                  value={userweight}
                  onChange={handleFieldChange} 
                />
            </label>
          </div>
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <div>
            <input type="submit" value="Submit" disabled={isSubmitting} />
          </div>
        </form>
      </>
      ) : (<h4>You must be logged in to post a weight</h4>)}
    </main>
  );
};
//
export default Main;
