function Aside(){
  return (
    <aside>
      <section>
        <h4>Health News</h4>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do 
        </p>
      </section>
      <section>
        <h4>Healthy Recipes</h4>
        <a href="">grilled chicken</a>
        <a href="">minced beef patties</a>
        <a href="">potato pancakes</a>
        <a href="">fish stew</a>
      </section>
    </aside>
  )
};
//
export default Aside;
