import { useState, useEffect, useMemo } from "react";
//
function Main() {
  const [allEmployees, setAllEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

    useEffect(()=>{
      setLoading(true);
      setError(null);
      
      fetch("http://localhost:3030/employees")
      .then(data => {
        if (!data.ok) {
          throw new Error(`HTTP error! status: ${data.status}`);
        }
        return data.json();
      })
      .then(resolvedData => {
        setAllEmployees(resolvedData);
        setLoading(false);
      })
      .catch((error)=>{
        console.error("Error fetching employees:", error.message);
        setError(`Failed to load employees: ${error.message}`);
        setLoading(false);
      });
    },[]);

    const sortedEmployees = useMemo(() => {
      return [...allEmployees].sort((a, b) => a.username.localeCompare(b.username));
    }, [allEmployees]);

    if (loading) {
      return (
        <main>
          <h2>Employee List</h2>
          <div className="loading">Loading employees...</div>
        </main>
      );
    }

    if (error) {
      return (
        <main>
          <h2>Employee List</h2>
          <div className="error">{error}</div>
          <button onClick={() => window.location.reload()}>Try Again</button>
        </main>
      );
    }

    return (
      <main className="employees-main">
        <h2>Employee List ({allEmployees.length})</h2>
        
        {sortedEmployees.length === 0 ? (
          <div className="no-data">No employees found.</div>
        ) : (
          <div className="employees-grid">
            {sortedEmployees.map((employee) =>
              (<div key={employee.id || employee.username} className="employee-card">
                <h3>{employee.username}</h3>
                <span className="employee-status">Active</span>
              </div>)
            )}
          </div>
        )}
      </main>
    )
  };
//
export default Main;
