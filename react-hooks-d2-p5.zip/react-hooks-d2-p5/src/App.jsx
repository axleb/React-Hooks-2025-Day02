import "./styles.css";
import Home from "./components/home/home";
import Employees from "./components/employees/employees";
import Register from "./components/register/register";
import Login from "./components/login/login";
import EnterWeight from "./components/enterweight/enterweight.jsx";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./components/AuthContext.jsx";
//
function App() {
  return (
    <>
      <AuthProvider> 
        <BrowserRouter>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/employees' element={<Employees />} />
            <Route path='/register' element={<Register />} />
            <Route path='/enterweight' element={<EnterWeight />} />
            <Route path="/login" element={<Login />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </>
  )
};
//
export default App;
