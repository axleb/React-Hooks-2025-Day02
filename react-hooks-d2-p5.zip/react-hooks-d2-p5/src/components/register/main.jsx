import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../AuthContext";
//
function Main() {
//
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

//
  const handleFieldChange = (event) => {
    const { name, value } = event.target;
    if (name === "username") setUsername(value);
    if (name === "password") setPassword(value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    fetch('http://localhost:3030/employees', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        username: username,
        password: password
      })
    })
    .then(response => response.text())
    .then(user => {
      login({ username, password });
      setUsername("");
      setPassword("");
      setIsSubmitting(true);
      console.log(user);
      navigate("/");
    })
    .catch(err => {
      console.log("An error occured! " + err.message);
    });
  };
//
  return (
    <main>
      <h2>Register for the competition</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>
            Name:
              <input 
              type="text" 
              name="username" 
              onChange={handleFieldChange} />
          </label>
        </div>
        <div>
          <label>
            Password:
              <input 
              type="text" 
              name="password" 
              onChange={handleFieldChange} />
          </label>
        </div>
        <div>
          <input type="submit" value="Submit" disabled={isSubmitting} />
        </div>
      </form>
    </main>
  );
};
//
export default Main;
