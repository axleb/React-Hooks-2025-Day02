import logo from "./../../assets/chart.gif";
import { NavLink } from "react-router-dom";
import {useContext} from "react";
import {AuthContext} from "./../AuthContext";
//
function Header(){
  const {user} = useContext(AuthContext);
//
  return (
    <header>
      <img src={logo} id="logo" />
			<h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
      <nav>

        <ul>
          <li><NavLink to="/">home</NavLink></li>
          <li><NavLink to="/register">register</NavLink></li>
          <li><NavLink to="/employees">employees</NavLink></li>

          { !user? (
            <li><NavLink to="/login">login</NavLink></li>
            ):(
            <li> <NavLink to="/logout"> {user.username}</NavLink></li>
          )}

        </ul>
      </nav>
    </header>
  )
};
//
export default Header;
//


